// custom js
const navbarNav = document.querySelector(".navbar-icon-link-hover");

function MyFunction() {
  const navshow = document.querySelector(".navbar-icon-link-hover");
  navshow.classList.toggle("active");
}
