# kedaikopi.id
website sederhana cafe yang menjual beberapa menu kopi dan makanan cepat saji lainnya, website ini saya buat untuk kepentingan belajar dan tugas project web.

```bash
Author : Wahyu TC
UI/UX  : Hawkxc
branch : master
```
